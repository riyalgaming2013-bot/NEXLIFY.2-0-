
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
    GoogleGenAI, 
    LiveServerMessage, 
    Modality,
    FunctionDeclaration, 
    Type 
} from '@google/genai';
import { Mic, MicOff, Power, Activity, Wifi, Settings, Volume2, Smartphone, Zap, Globe, MessageSquare, User, Check } from 'lucide-react';

import AudioVisualizer from './components/AudioVisualizer';
import ActionLog from './components/ActionLog';
import ChatInterface from './components/ChatInterface';
import PermissionsModal from './components/PermissionsModal';
import { createPcmBlob, decodeAudioData, base64ToUint8Array } from './services/audioUtils';
import { LogEntry, ConnectionState, ChatMessage, GeminiVoice, MOCK_ENV } from './types';
import { SYSTEM_INSTRUCTION, GEMINI_MODEL, DEFAULT_VOICE } from './constants';

// Tool Definition
const executeActionTool: FunctionDeclaration = {
  name: 'execute_action',
  description: 'Executes a structured action. Use this for Flashlight, App Searches (YouTube, etc), and URL opening.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      action: { type: Type.STRING, description: 'Action type: toggle_flashlight, search_app, search_web, open_url, get_time' },
      device_id: { type: Type.STRING, description: 'The target device ID' },
      appName: { type: Type.STRING, description: 'Name of the app to search/open (e.g., YouTube, Instagram, Chrome)' },
      url: { type: Type.STRING, description: 'Specific URL to open if provided' },
      query: { type: Type.STRING, description: 'Search query terms' },
      state: { type: Type.STRING, description: 'on/off for flashlight' },
      payload: { type: Type.STRING, description: 'Raw JSON payload if complex' }
    },
    required: ['action', 'device_id']
  }
};

// Comprehensive Voice List (Male & Female)
const VOICES: { id: GeminiVoice; label: string; gender: 'male' | 'female'; desc: string }[] = [
    { id: 'Puck', label: 'Jarvis (Standard)', gender: 'male', desc: 'Classic Male Voice' },
    { id: 'Fenrir', label: 'Jarvis (Deep)', gender: 'male', desc: 'Deep & Authoritative' },
    { id: 'Kore', label: 'Friday (Female)', gender: 'female', desc: 'Calm & Natural' },
    { id: 'Zephyr', label: 'Voice A (Female)', gender: 'female', desc: 'Soft & Helpful' },
    { id: 'Charon', label: 'Voice B (Male)', gender: 'male', desc: 'Deep & Serious' },
];

const App: React.FC = () => {
    // State
    const [connectionState, setConnectionState] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
    const [hasPermissions, setHasPermissions] = useState(false);
    const [isMuted, setIsMuted] = useState(false);
    const [selectedVoice, setSelectedVoice] = useState<GeminiVoice>('Puck'); // Default to Puck (Male)
    const [isFlashlightActive, setIsFlashlightActive] = useState(false); // UI state only
    const [showVoiceMenu, setShowVoiceMenu] = useState(false); // Toggle for voice menu
    
    // Refs for Logic (Persist across renders/closures)
    const audioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const inputProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const outputAnalyserRef = useRef<AnalyserNode | null>(null);
    const nextStartTimeRef = useRef<number>(0);
    const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const torchTrackRef = useRef<MediaStreamTrack | null>(null); // Critical for flashlight toggle

    // Helper to add logs
    const addLog = useCallback((type: LogEntry['type'], text: string, payload?: any) => {
        setLogs(prev => [...prev, {
            id: Math.random().toString(36).substring(7),
            timestamp: new Date().toISOString(),
            type,
            text,
            payload
        }]);
    }, []);

    // Add Chat Message
    const addChatMessage = useCallback((role: 'user' | 'ai', text: string, isFinal = true) => {
        setChatMessages(prev => {
            const lastMsg = prev[prev.length - 1];
            // Combine partials if same role and not final
            if (lastMsg && lastMsg.role === role && !lastMsg.isFinal) {
                return [
                    ...prev.slice(0, -1),
                    { ...lastMsg, text: lastMsg.text + text, isFinal }
                ];
            }
            return [...prev, {
                id: Math.random().toString(36).substring(7),
                role,
                text,
                timestamp: new Date(),
                isFinal
            }];
        });
    }, []);

    // Smart Browser TTS - Syncs with Selected Gemini Voice Gender
    const speakResponse = useCallback((text: string) => {
        if (!window.speechSynthesis) return;
        
        // Cancel previous speech to avoid overlap
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        const voices = window.speechSynthesis.getVoices();
        
        // Find the gender of the currently selected Live Voice
        const currentVoiceData = VOICES.find(v => v.id === selectedVoice);
        const targetGender = currentVoiceData?.gender || 'male';

        let preferredVoice: SpeechSynthesisVoice | undefined;

        // Strict Filtering Strategy
        if (targetGender === 'male') {
            // 1. Explicitly look for 'Male' in the name
            preferredVoice = voices.find(v => v.name.toLowerCase().includes('male'));
            
            // 2. Look for known male voices if generic 'Male' not found
            if (!preferredVoice) {
                preferredVoice = voices.find(v => 
                    v.name.includes('David') || 
                    v.name.includes('Guy') ||
                    v.name.includes('Daniel')
                );
            }
            utterance.pitch = 0.9; // Lower pitch for male
        } else {
            // 1. Explicitly look for 'Female' in the name
            preferredVoice = voices.find(v => v.name.toLowerCase().includes('female'));
            
            // 2. Look for known female voices
            if (!preferredVoice) {
                preferredVoice = voices.find(v => 
                    v.name.includes('Zira') || 
                    v.name.includes('Susan') ||
                    v.name.includes('Samantha')
                );
            }
            utterance.pitch = 1.0; 
        }

        // 3. Absolute Fallback: If still null, pick FIRST voice that matches language, 
        // trying to avoid the wrong gender if possible, but browser lists are messy.
        if (!preferredVoice) {
             preferredVoice = voices.find(v => v.lang.startsWith('en'));
        }

        if (preferredVoice) {
            // addLog('system', `TTS using voice: ${preferredVoice.name}`);
            utterance.voice = preferredVoice;
        }

        utterance.rate = 1.0; 
        window.speechSynthesis.speak(utterance);
    }, [selectedVoice]); // Dependency on selectedVoice ensures we use fresh state

    // Initialize Gemini Live
    const connectToGemini = async (voiceOverride?: GeminiVoice) => {
        if (!process.env.API_KEY) {
            alert("API_KEY is missing!");
            return;
        }

        const voiceToUse = voiceOverride || selectedVoice;

        try {
            setConnectionState(ConnectionState.CONNECTING);
            
            // 1. Audio Context
            const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
            const ctx = new AudioContextClass({ sampleRate: 24000 });
            audioContextRef.current = ctx;
            
            const analyser = ctx.createAnalyser();
            analyser.fftSize = 256;
            analyser.connect(ctx.destination);
            outputAnalyserRef.current = analyser;
            
            // 2. Input Stream
            const stream = await navigator.mediaDevices.getUserMedia({ 
                audio: {
                    sampleRate: 16000,
                    channelCount: 1,
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                } 
            });
            mediaStreamRef.current = stream;

            // 3. Gemini Client
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            const sessionPromise = ai.live.connect({
                model: GEMINI_MODEL,
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: {
                        voiceConfig: { prebuiltVoiceConfig: { voiceName: voiceToUse } } // Dynamic Voice Selection
                    },
                    systemInstruction: SYSTEM_INSTRUCTION,
                    tools: [{ functionDeclarations: [executeActionTool] }],
                    inputAudioTranscription: {}, 
                    outputAudioTranscription: {} 
                },
                callbacks: {
                    onopen: () => {
                        setConnectionState(ConnectionState.CONNECTED);
                        addLog('system', `Connected to Jarvis (Voice: ${voiceToUse})`);
                        
                        const inputCtx = new AudioContextClass({ sampleRate: 16000 });
                        const source = inputCtx.createMediaStreamSource(stream);
                        const processor = inputCtx.createScriptProcessor(4096, 1, 1);
                        
                        processor.onaudioprocess = (e) => {
                            if (isMuted) return;
                            const inputData = e.inputBuffer.getChannelData(0);
                            const pcmBlob = createPcmBlob(inputData);
                            sessionPromiseRef.current?.then(session => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };

                        source.connect(processor);
                        processor.connect(inputCtx.destination);
                        inputProcessorRef.current = processor;
                    },
                    onmessage: async (msg: LiveServerMessage) => {
                        // 1. Handle Transcriptions
                        if (msg.serverContent?.inputTranscription) {
                             const text = msg.serverContent.inputTranscription.text;
                             if (text) addChatMessage('user', text, false);
                        }

                        if (msg.serverContent?.outputTranscription) {
                            const text = msg.serverContent.outputTranscription.text;
                            if (text) addChatMessage('ai', text, false); 
                        }
                        
                        if (msg.serverContent?.turnComplete) {
                           setChatMessages(prev => {
                               const lastIndex = prev.length - 1;
                               if (lastIndex >= 0) {
                                   const updated = [...prev];
                                   updated[lastIndex] = { ...updated[lastIndex], isFinal: true };
                                   return updated;
                               }
                               return prev;
                           });
                        }

                        // 2. Handle Tool Calls
                        if (msg.toolCall) {
                            addLog('system', 'Jarvis is processing command...');
                            for (const fc of msg.toolCall.functionCalls) {
                                if (fc.name === 'execute_action') {
                                    const result = await handleToolAction(fc.args);
                                    sessionPromiseRef.current?.then(session => {
                                        session.sendToolResponse({
                                            functionResponses: {
                                                id: fc.id,
                                                name: fc.name,
                                                response: { result }
                                            }
                                        });
                                    });
                                }
                            }
                        }

                        // 3. Handle Audio
                        const audioData = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                        if (audioData) {
                            if (audioContextRef.current) {
                                const ctx = audioContextRef.current;
                                nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                                const audioBuffer = await decodeAudioData(base64ToUint8Array(audioData), ctx, 24000);
                                const source = ctx.createBufferSource();
                                source.buffer = audioBuffer;
                                source.connect(outputAnalyserRef.current!);
                                source.start(nextStartTimeRef.current);
                                nextStartTimeRef.current += audioBuffer.duration;
                                sourcesRef.current.add(source);
                                source.onended = () => sourcesRef.current.delete(source);
                            }
                        }
                        
                        // 4. Interruption
                         if (msg.serverContent?.interrupted) {
                             addLog('system', 'Interrupted');
                             sourcesRef.current.forEach(s => s.stop());
                             sourcesRef.current.clear();
                             if (audioContextRef.current) nextStartTimeRef.current = audioContextRef.current.currentTime;
                         }
                    },
                    onclose: () => {
                        setConnectionState(ConnectionState.DISCONNECTED);
                        addLog('system', 'Disconnected');
                    },
                    onerror: (e) => {
                        console.error(e);
                        setConnectionState(ConnectionState.ERROR);
                    }
                }
            });

            sessionPromiseRef.current = sessionPromise;

        } catch (error) {
            console.error(error);
            setConnectionState(ConnectionState.ERROR);
        }
    };

    // Send Text Message Logic - Uses Standard API for reliability
    const handleSendTextMessage = useCallback(async (text: string) => {
        if (!text.trim()) return;
        
        if (!process.env.API_KEY) {
             addLog('system', 'Error: API Key is missing in environment.');
             return;
        }
        
        // Show user message
        addChatMessage('user', text, true);

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            // Use standard model for text interactions to avoid Live API session issues
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: [
                    { 
                        role: 'user', 
                        parts: [{ text: text }] 
                    }
                ],
                config: {
                    // Pass system instruction as a properly formatted part to avoid parsing issues
                    systemInstruction: {
                        parts: [{ text: SYSTEM_INSTRUCTION }]
                    },
                    tools: [{ functionDeclarations: [executeActionTool] }]
                }
            });

            const calls = response.functionCalls;
            
            if (calls && calls.length > 0) {
                for (const call of calls) {
                     // Execute action
                     await handleToolAction(call.args);
                }
            }

            const responseText = response.text;
            if (responseText) {
                addChatMessage('ai', responseText, true);
                speakResponse(responseText);
            } else if (calls && calls.length > 0) {
                const ack = "Action executed, sir.";
                addChatMessage('ai', ack, true);
                speakResponse(ack);
            }

        } catch (err: any) {
            console.error("Gemini Text API Error:", err);
            addLog('system', 'Text Chat Error: ' + (err.message || 'Network/API Failure'));
            addChatMessage('ai', "I apologize, but I encountered a connection error. Please check your internet or API key.", true);
        }
    }, [addChatMessage, addLog, speakResponse]);


    // Tool Handler (Smart App Routing & URL Support)
    const handleToolAction = async (actionData: any) => {
        addLog('action', `Executing: ${actionData.action}`, actionData);

        let result = { status: 'success', message: 'Action executed' };

        switch (actionData.action) {
            case 'toggle_flashlight':
                // Web Flashlight Logic using Ref to ensure persistence
                const desiredState = actionData.state;
                
                if (desiredState === 'on') {
                    try {
                        if (torchTrackRef.current) {
                             addLog('system', 'Flashlight is already active');
                             result = { status: 'success', message: 'Flashlight is already on' };
                             break;
                        }
                        const stream = await navigator.mediaDevices.getUserMedia({ 
                            video: { facingMode: 'environment' } 
                        });
                        const track = stream.getVideoTracks()[0];
                        const capabilities = track.getCapabilities() as any;
                        
                        if (capabilities.torch) {
                            await track.applyConstraints({ advanced: [{ torch: true } as any] });
                            torchTrackRef.current = track;
                            setIsFlashlightActive(true);
                            addLog('system', 'Flashlight turned ON');
                            result = { status: 'success', message: 'Flashlight is now ON' };
                        } else {
                            track.stop(); 
                            addLog('system', 'Flashlight hardware not found on this device.');
                            result = { status: 'error', message: 'Flashlight not supported on this device.' };
                        }
                    } catch (e) {
                        console.error(e);
                        addLog('system', 'Camera permission denied or unavailable.');
                        result = { status: 'error', message: 'Permission denied or camera in use.' };
                    }
                } else {
                    // Turn OFF
                    if (torchTrackRef.current) {
                        torchTrackRef.current.stop();
                        torchTrackRef.current = null;
                        setIsFlashlightActive(false);
                        addLog('system', 'Flashlight turned OFF');
                        result = { status: 'success', message: 'Flashlight is now OFF' };
                    } else {
                        addLog('system', 'Flashlight was already OFF');
                        result = { status: 'success', message: 'Flashlight is already OFF' };
                    }
                }
                break;

            case 'search_app':
            case 'search_web':
            case 'open_url':
                // 1. Logic to determine the specific URL
                let targetUrl = actionData.url;
                const query = actionData.query || '';
                const appName = (actionData.appName || '').toLowerCase();

                // A. If explicit URL provided (e.g., "open this link...")
                if (!targetUrl) {
                    // Check if the query itself is a URL
                    if (query.startsWith('http') || query.match(/^www\./)) {
                        targetUrl = query.startsWith('www') ? `https://${query}` : query;
                    }
                }

                // B. App Routing Logic
                if (!targetUrl) {
                    if (appName.includes('youtube') || query.toLowerCase().includes('youtube')) {
                        // Clean query by removing "youtube" to avoid double terms
                        const cleanQuery = query.replace(/youtube/gi, '').replace(/search/gi, '').replace(/on/gi, '').trim();
                        // If query is empty after cleaning, just open YouTube home
                        targetUrl = cleanQuery 
                            ? `https://www.youtube.com/results?search_query=${encodeURIComponent(cleanQuery)}`
                            : `https://www.youtube.com`;
                    } else if (appName.includes('instagram')) {
                        targetUrl = `https://www.instagram.com/`;
                    } else if (appName.includes('facebook')) {
                        targetUrl = `https://www.facebook.com/`;
                    } else if (appName.includes('twitter') || appName.includes('x.com')) {
                        targetUrl = `https://x.com/search?q=${encodeURIComponent(query)}`;
                    } else {
                        // Default to Google Search
                        targetUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
                    }
                }
                
                addLog('system', `Opening: ${targetUrl}`);
                // Open in new tab
                window.open(targetUrl, '_blank');
                result = { status: 'success', message: `Opened ${targetUrl}` };
                break;
                
            case 'get_time':
                result = { status: 'success', message: new Date().toLocaleTimeString() } as any;
                break;
                
            default:
                addLog('system', 'Action executed.');
                break;
        }

        return result;
    };

    // Cleanup function
    const cleanup = useCallback(() => {
        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }
        // Stop flashlight if active
        if (torchTrackRef.current) {
            torchTrackRef.current.stop();
            torchTrackRef.current = null;
            setIsFlashlightActive(false);
        }
        
        if (inputProcessorRef.current) {
            inputProcessorRef.current.disconnect();
            inputProcessorRef.current = null;
        }
        if (audioContextRef.current) {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }
        sourcesRef.current.forEach(source => source.stop());
        sourcesRef.current.clear();
        sessionPromiseRef.current = null;
        setConnectionState(ConnectionState.DISCONNECTED);
    }, []);

    const toggleConnection = () => {
        if (connectionState === ConnectionState.CONNECTED || connectionState === ConnectionState.CONNECTING) {
            cleanup();
        } else {
            connectToGemini();
        }
    };

    // Logic to switch voice mid-stream
    const handleVoiceChange = (newVoice: GeminiVoice) => {
        setSelectedVoice(newVoice);
        setShowVoiceMenu(false);
        
        // If connected, reconnect with new voice to apply immediately
        if (connectionState === ConnectionState.CONNECTED) {
            addLog('system', 'Switching voice profile...');
            cleanup();
            // Small delay to allow cleanup to complete
            setTimeout(() => {
                connectToGemini(newVoice);
            }, 300);
        }
    };

    return (
        <div className="min-h-screen bg-[#050505] text-gray-100 flex flex-col items-center relative overflow-hidden font-sans selection:bg-pink-500/30">
            
            <PermissionsModal 
                isOpen={!hasPermissions} 
                onRequestPermissions={async () => {
                    try {
                        await navigator.mediaDevices.getUserMedia({ audio: true });
                        setHasPermissions(true);
                    } catch(e) { alert("Permissions required"); }
                }} 
            />

            {/* Ambient Background */}
            <div className="fixed inset-0 pointer-events-none">
                <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-pink-600/10 rounded-full blur-[120px] transition-opacity duration-1000 ${connectionState === ConnectionState.CONNECTED ? 'opacity-100' : 'opacity-20'}`}></div>
            </div>

            {/* Flashlight Indicator (Subtle) */}
            {isFlashlightActive && (
                <div className="absolute top-4 left-4 z-50 bg-yellow-500/20 border border-yellow-500/50 text-yellow-300 px-3 py-1 rounded-full flex items-center gap-2 animate-pulse shadow-[0_0_15px_rgba(234,179,8,0.3)]">
                    <Zap size={14} fill="currentColor" />
                    <span className="text-xs font-bold font-tech">FLASHLIGHT ON</span>
                </div>
            )}

            {/* Header */}
            <header className="w-full max-w-6xl mx-auto px-6 py-6 z-20 flex items-center justify-between">
                 <div className="flex items-center gap-3">
                    <div className="relative">
                        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-gray-900 to-black border border-pink-500/50 flex items-center justify-center shadow-[0_0_15px_rgba(236,72,153,0.3)]">
                            <Activity size={20} className="text-pink-500" />
                        </div>
                        <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-black"></div>
                    </div>
                    <div>
                        <h1 className="font-tech text-2xl font-bold text-white tracking-wider neon-text leading-none">
                            JARVIS<span className="text-pink-500">.AI</span>
                        </h1>
                        <span className="text-[10px] text-gray-500 font-code tracking-[0.2em]">BASE44 SYSTEM // ONLINE</span>
                    </div>
                 </div>

                 <div className="flex items-center gap-4">
                    {/* Language Badge */}
                    <div className="hidden md:flex items-center gap-2 bg-blue-900/20 border border-blue-800/50 text-blue-400 rounded-full px-3 py-1">
                        <Globe size={12} />
                        <span className="text-[10px] font-bold tracking-wider">AUTO-LANG</span>
                    </div>

                    {/* Advanced Voice Selector */}
                    <div className="relative">
                        <button 
                            onClick={() => setShowVoiceMenu(!showVoiceMenu)}
                            className="flex items-center gap-2 bg-gray-900/50 border border-gray-800 rounded-full px-4 py-2 hover:bg-gray-800 transition-colors"
                        >
                            <Volume2 size={14} className={VOICES.find(v => v.id === selectedVoice)?.gender === 'female' ? 'text-purple-400' : 'text-blue-400'}/>
                            <span className="text-xs font-medium text-gray-300">{VOICES.find(v => v.id === selectedVoice)?.label}</span>
                        </button>
                        
                        {/* Voice Dropdown Menu */}
                        {showVoiceMenu && (
                            <div className="absolute right-0 mt-2 w-64 bg-black/90 border border-gray-800 rounded-xl p-2 backdrop-blur-xl shadow-[0_0_20px_rgba(0,0,0,0.5)] z-50">
                                <div className="text-[10px] font-bold text-gray-500 px-3 py-2 uppercase tracking-wider">Select Voice Personality</div>
                                {VOICES.map(v => (
                                    <button
                                        key={v.id}
                                        onClick={() => handleVoiceChange(v.id)}
                                        className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between text-xs group ${selectedVoice === v.id ? 'bg-gray-800' : 'hover:bg-gray-900'}`}
                                    >
                                        <div>
                                            <div className={`font-bold ${v.gender === 'male' ? 'text-blue-400' : 'text-purple-400'}`}>
                                                {v.label}
                                            </div>
                                            <div className="text-gray-500 text-[10px]">{v.desc}</div>
                                        </div>
                                        {selectedVoice === v.id && <Check size={14} className="text-green-400" />}
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    <div className={`flex items-center gap-2 px-4 py-2 rounded-full border backdrop-blur-sm transition-colors ${
                        connectionState === ConnectionState.CONNECTED 
                        ? 'border-green-500/50 bg-green-500/10 text-green-400 shadow-[0_0_10px_rgba(34,197,94,0.2)]' 
                        : 'border-gray-800 bg-gray-900/50 text-gray-500'
                    }`}>
                        <Wifi size={14} />
                        <span className="text-xs font-bold tracking-wider">{connectionState}</span>
                    </div>
                 </div>
            </header>

            {/* Main Layout */}
            <main className="flex-1 w-full max-w-6xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 z-10">
                
                {/* Left Column: Visualizer & Controls (4 Cols) */}
                <div className="lg:col-span-4 flex flex-col gap-6">
                    
                    {/* Visualizer Card */}
                    <div className="flex-1 bg-gray-900/40 border border-gray-800 rounded-2xl p-8 flex flex-col items-center justify-center relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-b from-pink-500/5 to-transparent opacity-50"></div>
                        
                        <div className="relative z-10">
                            <AudioVisualizer 
                                analyser={outputAnalyserRef.current} 
                                isActive={connectionState === ConnectionState.CONNECTED} 
                            />
                        </div>

                        {/* Floating Status Text */}
                        <div className="mt-8 text-center space-y-1">
                            <p className="text-pink-400 font-code text-xs tracking-widest animate-pulse">
                                {connectionState === ConnectionState.CONNECTED ? 'LISTENING / READY' : 'STANDBY MODE'}
                            </p>
                            <div className="flex items-center justify-center gap-2 text-gray-500 text-[10px]">
                                <User size={10} />
                                <span>Active Personality: {VOICES.find(v => v.id === selectedVoice)?.label}</span>
                            </div>
                        </div>
                    </div>

                    {/* Control Bar */}
                    <div className="bg-gray-900/60 border border-gray-800 rounded-2xl p-6 flex items-center justify-between backdrop-blur-sm">
                        <button 
                            onClick={() => setIsMuted(!isMuted)}
                            className={`p-4 rounded-xl border transition-all duration-300 ${
                                isMuted 
                                ? 'bg-red-500/10 border-red-500/50 text-red-400 hover:bg-red-500/20' 
                                : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-pink-500 hover:text-pink-400'
                            }`}
                        >
                            {isMuted ? <MicOff size={20} /> : <Mic size={20} />}
                        </button>

                        <button 
                            onClick={toggleConnection}
                            className={`relative group px-8 py-4 rounded-xl font-bold tracking-wider transition-all duration-300 flex items-center gap-3 overflow-hidden ${
                                connectionState === ConnectionState.CONNECTED
                                ? 'bg-pink-600 text-white shadow-[0_0_20px_#ec4899] hover:bg-pink-500'
                                : 'bg-white/5 text-gray-300 hover:bg-white/10 border border-white/10'
                            }`}
                        >
                            <Power size={20} />
                            {connectionState === ConnectionState.CONNECTED ? 'DISCONNECT' : 'INITIALIZE'}
                            
                            {connectionState !== ConnectionState.CONNECTED && (
                                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
                            )}
                        </button>
                    </div>
                </div>

                {/* Middle Column: Chat Interface (5 Cols) */}
                <div className="lg:col-span-5 h-[500px] lg:h-auto min-h-[400px]">
                    <ChatInterface 
                        messages={chatMessages} 
                        onSendMessage={handleSendTextMessage}
                        disabled={false} 
                    />
                </div>

                {/* Right Column: System Logs / Status (3 Cols) */}
                <div className="lg:col-span-3 flex flex-col gap-4 h-[300px] lg:h-auto">
                    <div className="bg-black/40 border border-gray-800 rounded-xl p-4 flex items-center gap-3">
                         <div className="p-2 bg-blue-500/10 rounded-lg text-blue-400"><Smartphone size={18} /></div>
                         <div>
                             <div className="text-xs text-gray-500 font-code">DEVICE STATUS</div>
                             <div className="text-sm font-bold text-gray-200">{isFlashlightActive ? 'FLASHLIGHT ON' : 'OPTIMAL'}</div>
                         </div>
                    </div>

                    <div className="bg-black/40 border border-gray-800 rounded-xl p-4 flex items-center gap-3">
                         <div className="p-2 bg-purple-500/10 rounded-lg text-purple-400"><Settings size={18} /></div>
                         <div>
                             <div className="text-xs text-gray-500 font-code">MODEL</div>
                             <div className="text-sm font-bold text-gray-200">Gemini 2.5 Flash</div>
                         </div>
                    </div>

                    <div className="flex-1 min-h-0 border border-gray-800 rounded-xl overflow-hidden bg-black">
                        <ActionLog logs={logs} />
                    </div>
                </div>

            </main>
        </div>
    );
};

export default App;
