
export interface LogEntry {
  id: string;
  timestamp: string;
  type: 'user' | 'ai' | 'system' | 'action';
  text: string;
  payload?: any;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'ai';
  text: string;
  timestamp: Date;
  isFinal?: boolean;
}

export enum ConnectionState {
  DISCONNECTED = 'DISCONNECTED',
  CONNECTING = 'CONNECTING',
  CONNECTED = 'CONNECTED',
  ERROR = 'ERROR',
}

export interface JarvisAction {
  action: string;
  device_id: string;
  [key: string]: any;
}

// Audio Types
export interface AudioContextConfig {
  sampleRate: number;
}

// Mock Bridge Env
export const MOCK_ENV = {
  DEVICE_ID: "device_web_client_001",
  MALE_VOICE_ID: "eleven_male_001", // Mapped to Gemini 'Puck' or 'Fenrir'
  FEMALE_VOICE_ID: "eleven_female_001", // Mapped to Gemini 'Kore' or 'Aoede'
};

export type GeminiVoice = 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' | 'Aoede';
