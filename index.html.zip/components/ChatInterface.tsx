import React, { useEffect, useRef, useState } from 'react';
import { ChatMessage } from '../types';
import { Bot, User, Send } from 'lucide-react';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage?: (text: string) => void;
  disabled?: boolean;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ messages, onSendMessage, disabled }) => {
  const bottomRef = useRef<HTMLDivElement>(null);
  const [inputText, setInputText] = useState('');

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim() && onSendMessage) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  return (
    <div className="flex flex-col h-full bg-black/40 backdrop-blur-sm border border-pink-900/30 rounded-xl overflow-hidden shadow-[0_0_15px_rgba(236,72,153,0.1)]">
      {/* Header */}
      <div className="bg-pink-950/30 px-6 py-4 border-b border-pink-900/30 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={`w-2 h-2 rounded-full ${disabled ? 'bg-gray-500' : 'bg-pink-500 animate-pulse'}`} />
          <span className="font-tech text-sm font-bold text-pink-100 tracking-wider">LIVE CHAT</span>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6 scroll-smooth">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-gray-600 gap-4 opacity-50">
             <Bot size={48} />
             <p className="font-code text-sm">Initialize to start chatting...</p>
          </div>
        )}
        
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
          >
            {/* Avatar */}
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              msg.role === 'ai' 
                ? 'bg-pink-600 text-white shadow-[0_0_10px_#ec4899]' 
                : 'bg-gray-700 text-gray-300'
            }`}>
              {msg.role === 'ai' ? <Bot size={16} /> : <User size={16} />}
            </div>

            {/* Bubble */}
            <div className={`flex flex-col max-w-[80%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`px-4 py-3 rounded-2xl text-sm font-medium leading-relaxed ${
                msg.role === 'ai'
                  ? 'bg-gradient-to-br from-pink-900/80 to-purple-900/80 text-pink-50 border border-pink-500/30 rounded-tl-none'
                  : 'bg-gray-800 text-gray-100 border border-gray-700 rounded-tr-none'
              }`}>
                {msg.text}
                {!msg.isFinal && (
                    <span className="inline-block w-1 h-4 ml-1 align-middle bg-current animate-pulse"/>
                )}
              </div>
              <span className="text-[10px] text-gray-500 mt-1 font-code px-1">
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-black/60 border-t border-pink-900/30">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input 
            type="text" 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={disabled ? "Connect to start chatting..." : "Type a message to Jarvis..."}
            disabled={disabled}
            className="flex-1 bg-gray-900/80 border border-gray-700 rounded-xl px-4 py-3 text-sm text-gray-200 focus:outline-none focus:border-pink-500/50 focus:ring-1 focus:ring-pink-500/20 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          />
          <button 
            type="submit" 
            disabled={disabled || !inputText.trim()}
            className="bg-pink-600 text-white p-3 rounded-xl hover:bg-pink-500 disabled:opacity-50 disabled:bg-gray-800 disabled:text-gray-500 transition-colors shadow-lg shadow-pink-900/30"
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;