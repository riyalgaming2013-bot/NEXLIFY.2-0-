import React, { useEffect, useRef } from 'react';

interface AudioVisualizerProps {
  analyser: AnalyserNode | null;
  isActive: boolean;
}

const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ analyser, isActive }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const draw = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      if (!analyser || !isActive) {
        // Idle state - glowing circle
        ctx.beginPath();
        ctx.arc(width / 2, height / 2, 40, 0, Math.PI * 2);
        ctx.strokeStyle = '#ec4899'; // Pink-500
        ctx.lineWidth = 2;
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#ec4899';
        ctx.stroke();
        
        // Inner dot
        ctx.beginPath();
        ctx.arc(width / 2, height / 2, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#ec4899';
        ctx.fill();
        
        animationRef.current = requestAnimationFrame(draw);
        return;
      }

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);
      analyser.getByteFrequencyData(dataArray);

      const centerX = width / 2;
      const centerY = height / 2;
      const radius = 50;

      ctx.beginPath();
      ctx.arc(centerX, centerY, radius - 10, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(236, 72, 153, 0.1)';
      ctx.fill();

      // Circular visualizer
      ctx.beginPath();
      for (let i = 0; i < bufferLength; i++) {
        // Only use lower frequencies for better visuals
        if (i > bufferLength / 2) break;
        
        const barHeight = (dataArray[i] / 255) * 60;
        const angle = (i / (bufferLength/2)) * Math.PI * 2;
        
        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY + Math.sin(angle) * radius;
        const x2 = centerX + Math.cos(angle) * (radius + barHeight);
        const y2 = centerY + Math.sin(angle) * (radius + barHeight);

        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
      }

      ctx.lineCap = 'round';
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#ec4899';
      ctx.shadowBlur = 15;
      ctx.shadowColor = '#ec4899';
      ctx.stroke();

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [analyser, isActive]);

  return (
    <canvas 
      ref={canvasRef} 
      width={300} 
      height={300} 
      className="w-64 h-64 sm:w-80 sm:h-80"
    />
  );
};

export default AudioVisualizer;