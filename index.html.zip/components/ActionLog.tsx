import React, { useEffect, useRef } from 'react';
import { LogEntry } from '../types';
import { Terminal, Cpu, Activity, ShieldCheck } from 'lucide-react';

interface ActionLogProps {
  logs: LogEntry[];
}

const ActionLog: React.FC<ActionLogProps> = ({ logs }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  return (
    <div className="flex flex-col h-full bg-black border border-pink-900/30 rounded-lg overflow-hidden relative">
        {/* Header */}
        <div className="bg-pink-900/20 px-4 py-2 flex items-center justify-between border-b border-pink-900/30">
            <div className="flex items-center gap-2 text-pink-500">
                <Terminal size={16} />
                <span className="font-tech text-xs font-bold tracking-wider">SYSTEM LOGS</span>
            </div>
            <div className="flex gap-1">
                <div className="w-2 h-2 rounded-full bg-pink-600 animate-pulse"></div>
            </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 font-code text-xs space-y-3 crt-scanline">
            {logs.length === 0 && (
                <div className="text-gray-600 italic text-center mt-10">
                    Waiting for system events...
                </div>
            )}
            {logs.map((log) => (
                <div key={log.id} className={`flex gap-3 ${log.type === 'action' ? 'pl-4 border-l-2 border-pink-500' : ''}`}>
                    <div className="text-gray-500 whitespace-nowrap min-w-[60px]">
                        {new Date(log.timestamp).toLocaleTimeString([], {hour12: false, hour: '2-digit', minute:'2-digit', second:'2-digit'})}
                    </div>
                    <div className="flex-1 break-words">
                        {log.type === 'system' && (
                            <span className="text-blue-400 font-bold">[SYS] </span>
                        )}
                        {log.type === 'user' && (
                            <span className="text-green-400 font-bold">[USR] </span>
                        )}
                        {log.type === 'ai' && (
                            <span className="text-pink-400 font-bold">[AI] </span>
                        )}
                        {log.type === 'action' && (
                             <div className="text-yellow-400 font-bold flex items-center gap-2 mb-1">
                                <Cpu size={14} />
                                <span>[EXEC]</span>
                             </div>
                        )}
                        
                        <span className={log.type === 'action' ? 'text-yellow-200' : 'text-gray-300'}>
                            {log.text}
                        </span>

                        {log.payload && (
                            <div className="mt-2 bg-pink-900/10 border border-pink-500/30 p-2 rounded text-pink-300 overflow-x-auto">
                                <pre>{JSON.stringify(log.payload, null, 2)}</pre>
                            </div>
                        )}
                    </div>
                </div>
            ))}
            <div ref={bottomRef} />
        </div>

        {/* Footer Status */}
        <div className="bg-black border-t border-pink-900/30 px-4 py-1 flex items-center justify-between text-[10px] text-gray-500 font-tech">
            <div className="flex items-center gap-4">
                <span className="flex items-center gap-1"><ShieldCheck size={10} /> SECURE_CONN</span>
                <span className="flex items-center gap-1"><Activity size={10} /> MEM: OPTIMAL</span>
            </div>
            <div>BASE44 KERNEL V2.5</div>
        </div>
    </div>
  );
};

export default ActionLog;