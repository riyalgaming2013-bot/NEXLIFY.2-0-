import React from 'react';
import { ShieldAlert, Check, X } from 'lucide-react';

interface PermissionsModalProps {
  isOpen: boolean;
  onRequestPermissions: () => void;
}

const PermissionsModal: React.FC<PermissionsModalProps> = ({ isOpen, onRequestPermissions }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
      <div className="bg-gray-900 border border-pink-500 rounded-xl p-6 max-w-md w-full shadow-[0_0_30px_rgba(236,72,153,0.3)]">
        <div className="flex items-center gap-3 mb-4 text-pink-500">
          <ShieldAlert size={32} />
          <h2 className="text-xl font-tech font-bold">ACCESS REQUIRED</h2>
        </div>
        <p className="text-gray-300 mb-6 font-light">
          To activate Jarvis Live functionality, the system requires access to your:
          <ul className="list-disc list-inside mt-2 space-y-1 text-gray-400 ml-2">
            <li>Microphone (Audio Input)</li>
            <li>Audio Output</li>
          </ul>
        </p>
        <div className="flex gap-3">
          <button 
            onClick={onRequestPermissions}
            className="flex-1 bg-pink-600 hover:bg-pink-500 text-white font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-pink-900/50"
          >
            <Check size={18} /> INITIALIZE
          </button>
        </div>
      </div>
    </div>
  );
};

export default PermissionsModal;